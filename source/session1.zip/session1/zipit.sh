zip session1.zip 20_newsgroups.tar.gz novels.zip setclass setclass.bat lab1.pdf CountWords3.java eclipse-netbeans.txt
mv session1.zip ../

